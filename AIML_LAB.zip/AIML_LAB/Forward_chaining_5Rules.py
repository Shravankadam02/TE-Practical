facts = {"fever": True, "cough": True, "body_pain": True}
rules = [
    (["fever", "cough"], "flu"),
    (["flu", "body_pain"], "viral_infection"),
    (["viral_infection"], "needs_rest"),
    (["fever"], "high_temperature"),
    (["cough", "body_pain"], "possible_infection")
]

print("Initial facts:", facts)
changed = True
while changed:
    changed = False
    for conditions, conclusion in rules:
        if all(facts.get(item, False) for item in conditions) and not facts.get(conclusion, False):
            facts[conclusion] = True
            changed = True
            print("Newly derived fact:", conclusion)
print("Final fact base:", facts)
