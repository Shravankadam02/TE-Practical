# Assignment 18: K-Means on Mall Customers - Elbow Method for k=1 to 10
import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

URL = "https://raw.githubusercontent.com/sharmaroshan/Clustering-of-Mall-Customers/master/Mall_Customers.csv"
df = pd.read_csv("Mall_Customers.csv" if os.path.exists("Mall_Customers.csv") else URL)
# Handle the common spacing difference in the dataset column name.
spending_col = next(c for c in df.columns if "spending" in c.lower())
income_col = next(c for c in df.columns if "annual income" in c.lower())
X = df[[income_col, spending_col]]
scaled = StandardScaler().fit_transform(X)
wcss = []
for k in range(1, 11):
    model = KMeans(n_clusters=k, init="k-means++", n_init=10, random_state=42)
    model.fit(scaled)
    wcss.append(model.inertia_)
    print(f"K={k}, Inertia={model.inertia_:.2f}")
plt.plot(range(1, 11), wcss, marker="o")
plt.xlabel("Number of clusters (k)")
plt.ylabel("Inertia / WCSS")
plt.title("Elbow Method - Mall Customers")
plt.xticks(range(1, 11))
plt.grid(True)
plt.show()
