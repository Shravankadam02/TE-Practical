from collections import deque

def bfs(maze, start, goal):
    rows, cols = len(maze), len(maze[0])

    queue = deque([(start, [start])])
    visited = {start}

    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    while queue:
        (x, y), path = queue.popleft()

        print("Visiting:", (x, y))

        if (x, y) == goal:
            return path

        for dx, dy in directions:
            nx, ny = x + dx, y + dy

            if (0 <= nx < rows and
                0 <= ny < cols and
                maze[nx][ny] == 0 and
                (nx, ny) not in visited):

                visited.add((nx, ny))
                queue.append(((nx, ny), path + [(nx, ny)]))

    return None


# Take maze size from user
rows = int(input("Enter number of rows: "))
cols = int(input("Enter number of columns: "))

# Take maze input
maze = []

print("Enter maze (0 = Free path, 1 = Blocked path):")

for i in range(rows):
    row = list(map(int, input(f"Enter row {i+1}: ").split()))
    maze.append(row)

# Display maze
print("\nMaze:")
for row in maze:
    print(row)

# Take start and goal positions
print("\nEnter starting position:")
sx = int(input("Enter start row: "))
sy = int(input("Enter start column: "))

print("\nEnter goal position:")
gx = int(input("Enter goal row: "))
gy = int(input("Enter goal column: "))

start = (sx, sy)
goal = (gx, gy)

if (not (0 <= sx < rows and 0 <= sy < cols and
         0 <= gx < rows and 0 <= gy < cols)):
    print("Invalid position!")

elif maze[sx][sy] == 1 or maze[gx][gy] == 1:
    print("Start or goal position is blocked!")

else:
    result = bfs(maze, start, goal)

    if result:
        print("\nShortest path using BFS:")
        print(result)
        print("Path length:", len(result) - 1)
    else:
        print("No path found!")
