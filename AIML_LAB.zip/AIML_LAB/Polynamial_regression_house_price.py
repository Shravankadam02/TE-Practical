# Assignment 15: Polynomial Regression (degree 2) - area to price
# Put House_Price.csv in this folder. It should contain area and price columns.
# The script also accepts common alternatives: total_sqft and price.
#import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

#if os.path.exists("House_Price.csv"):

#else:
#    raise FileNotFoundError("Place House_Price.csv beside this script.")

df = pd.read_csv("house-prices.csv")

area_col = next((c for c in ["area", "Area", "total_sqft", "sqft", "SqFt"] if c in df.columns), None)

price_col = next((c for c in ["price", "Price"] if c in df.columns), None)

if not area_col or not price_col:
    raise ValueError("CSV must contain area (or total_sqft) and price columns.")

df = df[[area_col, price_col]].copy()

df[area_col] = pd.to_numeric(df[area_col], errors="coerce")
df[price_col] = pd.to_numeric(df[price_col], errors="coerce")

df = df.dropna()

X, y = df[[area_col]], df[price_col]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = make_pipeline(
    PolynomialFeatures(degree=2, include_bias=False),
    LinearRegression()
)

model.fit(X_train, y_train)

pred = model.predict(X_test)

print("MSE:", mean_squared_error(y_test, pred))
print("MAE:", mean_absolute_error(y_test, pred))
print("R2:", r2_score(y_test, pred))

order = X_test[area_col].argsort()

plt.scatter(X_test[area_col], y_test, label="Test data")

plt.plot(
    X_test[area_col].iloc[order],
    pred[order],
    color="red",
    label="Degree-2 curve"
)

plt.xlabel(area_col)
plt.ylabel(price_col)
plt.title("Polynomial Regression - House Price")
plt.legend()
plt.show()



#if os.path.exists("House_Price.csv"):
#   df = pd.read_csv("House_Price.csv")
#else:#   raise FileNotFoundError("Place House_Price.csv beside this script.")

