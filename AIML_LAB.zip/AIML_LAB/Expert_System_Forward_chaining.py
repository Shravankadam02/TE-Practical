facts = {
    "GPA": True,
    "Projects": True,
    "Internship": False,
    "Communication": True,
    "Resume_Ready": True
}
rules = [
    (["GPA", "Projects"], "Technical_Fit"),
    (["Internship"], "Technical_Fit"),
    (["Communication", "Resume_Ready"], "Soft_Fit"),
    (["Technical_Fit", "Soft_Fit"], "Employable")
]

def forward_chaining(initial_facts, rules, goal):
    known = dict(initial_facts)
    changed = True
    while changed:
        changed = False
        for conditions, conclusion in rules:
            if all(known.get(condition, False) for condition in conditions):
                if not known.get(conclusion, False):
                    known[conclusion] = True
                    changed = True
                    print("Derived fact:", conclusion)
                    if conclusion == goal:
                        print("Goal reached:", goal)
                        return True, known
    print("Goal could not be proven:", goal)
    return known.get(goal, False), known

print("Initial facts:", facts)
result, final_facts = forward_chaining(facts, rules, "Employable")
print("Final facts:", final_facts)
