# Assignment 19: K-Means clustering, Elbow Method and Dendrogram
# Uses Mall Customers as a real-world dataset and plots income vs spending.
import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from scipy.cluster.hierarchy import linkage, dendrogram

URL = "https://raw.githubusercontent.com/sharmaroshan/Clustering-of-Mall-Customers/master/Mall_Customers.csv"
df = pd.read_csv("Mall_Customers.csv" if os.path.exists("Mall_Customers.csv") else URL)
income_col = next(c for c in df.columns if "annual income" in c.lower())
spending_col = next(c for c in df.columns if "spending" in c.lower())
X = df[[income_col, spending_col]]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

wcss = []
for k in range(1, 11):
    km = KMeans(n_clusters=k, init="k-means++", n_init=10, random_state=42)
    km.fit(X_scaled)
    wcss.append(km.inertia_)
plt.plot(range(1, 11), wcss, marker="o")
plt.xlabel("Number of clusters (k)")
plt.ylabel("Inertia / WCSS")
plt.title("Elbow Method")
plt.grid(True)
plt.show()

linked = linkage(X_scaled, method="ward")
plt.figure(figsize=(12, 6))
dendrogram(linked, truncate_mode="lastp", p=30)
plt.title("Dendrogram - Mall Customers")
plt.xlabel("Customer groups")
plt.ylabel("Ward distance")
plt.show()

# Choose k=5 as a commonly visible segmentation for this dataset.
k = 5
model = KMeans(n_clusters=k, init="k-means++", n_init=10, random_state=42)
df["Cluster"] = model.fit_predict(X_scaled)
centers = scaler.inverse_transform(model.cluster_centers_)
plt.scatter(df[income_col], df[spending_col], c=df["Cluster"], s=40)
plt.scatter(centers[:, 0], centers[:, 1], marker="X", s=220, label="Centroids")
plt.xlabel("Annual Income (k$)")
plt.ylabel("Spending Score (1-100)")
plt.title("Mall Customer Clusters")
plt.legend()
plt.show()
print(df.groupby("Cluster")[[income_col, spending_col]].mean())
