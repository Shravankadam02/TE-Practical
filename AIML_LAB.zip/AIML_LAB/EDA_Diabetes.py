
# Assignment 11: EDA - Diabetes Dataset

#import os
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

# Load datasetS
#URL = "https://raw.githubusercontent.com/plotly/datasets/master/diabetes.csv"

path = "diabetes.csv"

df = pd.read_csv("diabetes.csv")

print(df.head())
print(df.info())

# 1. Data cleaning: drop duplicates
df = df.drop_duplicates()

# 2. Missing values: report and impute with median
print("Missing values:\n", df.isna().sum())

df[:] = SimpleImputer(strategy="median").fit_transform(df)

# 3. Encoding: bin target into categories, then one-hot encode
df["risk"] = df["Outcome"].map({0: "low", 1: "high"})

df = pd.get_dummies(df, columns=["risk"], dtype=int)

# 4. Statistical analysis
print("Statistics:\n", df.describe().T)

target_column = "Outcome" if "Outcome" in df.columns else "target"

print("Correlation with target:\n",
      df.corr(numeric_only=True)[target_column].sort_values())

# 5. Visualization: histograms and boxplots
num = df.select_dtypes(include="number").columns.drop(
    ["risk_low", "risk_medium", "risk_high"],
    errors="ignore"
)

df[num].hist(bins=20, figsize=(12, 8))
plt.tight_layout()
plt.show()

df[num].plot(
    kind="box",
    subplots=True,
    layout=(3, 4),
    figsize=(12, 8)
)
plt.tight_layout()
plt.show()

# 6. Split first, then scale
X = df.drop(columns=[target_column])
y = df[target_column]

X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42
)

sc = StandardScaler().fit(X_train)

X_train_s = sc.transform(X_train)
X_test_s = sc.transform(X_test)

print("Train:", X_train_s.shape, "Test:", X_test_s.shape)
#df = pd.read_csv(path if os.path.exists(path) else URL)
