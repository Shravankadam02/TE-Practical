# Assignment 4: Depth First Search (DFS) for maze navigation

# Take maze size from user
rows = int(input("Enter number of rows: "))
cols = int(input("Enter number of columns: "))

# Take maze input
maze = []

print("Enter maze (0 = Free path, 1 = Blocked path):")

for i in range(rows):
    row = list(map(int, input(f"Enter row {i+1}: ").split()))
    maze.append(row)


def dfs(maze, start, goal):
    rows, cols = len(maze), len(maze[0])

    stack = [(start, [start])]
    visited = {start}

    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]

    while stack:
        (x, y), path = stack.pop()

        print("Visiting:", (x, y))

        if (x, y) == goal:
            return path

        for dx, dy in directions:
            nx, ny = x + dx, y + dy

            if (0 <= nx < rows and 0 <= ny < cols and
                    maze[nx][ny] == 0 and (nx, ny) not in visited):

                visited.add((nx, ny))
                stack.append(((nx, ny), path + [(nx, ny)]))

    return None


# Display maze
print("\nMaze:")
for row in maze:
    print(row)


# Take starting position
print("\nEnter starting position:")
sx = int(input("Enter start row: "))
sy = int(input("Enter start column: "))

# Take goal position
print("\nEnter goal position:")
gx = int(input("Enter goal row: "))
gy = int(input("Enter goal column: "))

start = (sx, sy)
goal = (gx, gy)


# Check and execute DFS
if not (0 <= sx < rows and 0 <= sy < cols and
        0 <= gx < rows and 0 <= gy < cols):
    print("Invalid position!")

elif maze[sx][sy] == 1 or maze[gx][gy] == 1:
    print("Start or goal position is blocked!")

else:
    result = dfs(maze, start, goal)

    if result:
        print("\nDFS path:", result)
    else:
        print("No path found!")
