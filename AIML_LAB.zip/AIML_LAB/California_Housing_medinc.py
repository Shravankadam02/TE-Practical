# Assignment 13: California Housing - MedInc as the only input feature
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

housing = fetch_california_housing(as_frame=True)
X = housing.data[["MedInc"]]
y = housing.target
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LinearRegression()
model.fit(X_train, y_train)
pred = model.predict(X_test)
print("Slope:", model.coef_[0])
print("Intercept:", model.intercept_)
print("MSE:", mean_squared_error(y_test, pred))
print("MAE:", mean_absolute_error(y_test, pred))
print("R2:", r2_score(y_test, pred))
plt.scatter(X_test["MedInc"], y_test, alpha=0.4, label="Actual test values")
order = X_test["MedInc"].argsort()
plt.plot(X_test["MedInc"].iloc[order], pred[order], color="red", label="Fitted line")
plt.xlabel("Median Income (MedInc)")
plt.ylabel("Median House Value")
plt.title("Linear Regression: California Housing")
plt.legend()
plt.show()
