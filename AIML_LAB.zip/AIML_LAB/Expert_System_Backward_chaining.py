facts = {
    "GPA": True,
    "Projects": True,
    "Internship": False,
    "Communication": True,
    "Resume_Ready": True
}
rules = [
    (["GPA", "Projects"], "Technical_Fit"),
    (["Internship"], "Technical_Fit"),
    (["Communication", "Resume_Ready"], "Soft_Fit"),
    (["Technical_Fit", "Soft_Fit"], "Employable")
]

def backward_chaining(goal, facts, rules, visited=None):
    if visited is None:
        visited = set()
    if facts.get(goal, False):
        print("Known fact:", goal)
        return True
    if goal in visited:
        return False
    visited.add(goal)
    for conditions, conclusion in rules:
        if conclusion == goal:
            print("Trying rule:", conditions, "->", conclusion)
            if all(backward_chaining(c, facts, rules, visited.copy()) for c in conditions):
                print("Proved:", goal)
                return True
    print("Could not prove:", goal)
    return False

print("Is the student employable?", backward_chaining("Employable", facts, rules))
