# Assignment 5: Informed Search for Travelling Salesman Problem
# Demonstrates Greedy Best First Search and A* (small TSP instance).
import heapq

distance = [
    [0, 10, 15, 20],
    [10, 0, 35, 25],
    [15, 35, 0, 30],
    [20, 25, 30, 0]
]
N = len(distance)

def greedy_tsp(start=0):
    unvisited = set(range(N)) - {start}
    tour, current, total = [start], start, 0
    while unvisited:
        nxt = min(unvisited, key=lambda city: distance[current][city])
        total += distance[current][nxt]
        tour.append(nxt)
        unvisited.remove(nxt)
        current = nxt
    total += distance[current][start]
    tour.append(start)
    return tour, total

# A* uses an admissible lower bound: minimum outgoing edge for each
# unvisited city plus a connection from current city and a return to start.
def lower_bound(current, unvisited, start):
    if not unvisited:
        return distance[current][start]
    connection = min(distance[current][u] for u in unvisited)
    remaining = 0
    for u in unvisited:
        candidates = [distance[u][v] for v in unvisited if v != u]
        candidates.append(distance[u][start])
        remaining += min(candidates)
    return connection + remaining

def astar_tsp(start=0):
    initial_unvisited = frozenset(set(range(N)) - {start})
    pq = [(lower_bound(start, initial_unvisited, start), 0, start, (start,), initial_unvisited)]
    best = {}
    while pq:
        f, cost, current, path, unvisited = heapq.heappop(pq)
        if not unvisited:
            return list(path) + [start], cost + distance[current][start]
        state = (current, unvisited)
        if best.get(state, float("inf")) <= cost:
            continue
        best[state] = cost
        for nxt in unvisited:
            new_unvisited = frozenset(unvisited - {nxt})
            new_cost = cost + distance[current][nxt]
            h = lower_bound(nxt, new_unvisited, start)
            heapq.heappush(pq, (new_cost + h, new_cost, nxt, path + (nxt,), new_unvisited))
    return None, float("inf")

print("Distance matrix:")
for row in distance:
    print(row)
print("Greedy Best First:", greedy_tsp())
print("A* optimal tour:", astar_tsp())
