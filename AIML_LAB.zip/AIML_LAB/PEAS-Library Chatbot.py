# Assignment 2: Rule-based College Library Chatbot
# PEAS: Performance = correct helpful replies; Environment = college library;
# Actuators = display reply; Sensors = user message/keywords.

def library_chatbot(message):
    text = message.lower()
    rules = {
        ("timing", "time", "hours", "open"): "Library timing: Monday to Saturday, 9:00 AM to 5:00 PM.",
        ("fine", "late fee", "penalty"): "A late return fine is charged according to the number of overdue days.",
        ("renew", "renewal", "extend"): "You can renew a book at the library counter or through the library portal.",
        ("membership", "member", "register", "registration"): "Students can get library membership using their college ID card."
    }
    for keywords, reply in rules.items():
        if any(word in text for word in keywords):
            return reply
    return "Sorry, I did not understand. Ask about timing, fine, renewal or membership."

print("College Library Chatbot (type 'exit' to stop)")
while True:
    user_message = input("You: ").strip()
    if user_message.lower() == "exit":
        print("Bot: Thank you. Goodbye!")
        break
    print("Bot:", library_chatbot(user_message))
