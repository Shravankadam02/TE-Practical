# Assignment 5: Informed Search for Travelling Salesman Problem
# Greedy Best First Search and A*

import heapq

# Take number of cities
N = int(input("Enter number of cities: "))

# Take distance matrix from user
distance = []

print("Enter distance matrix:")

for i in range(N):
    row = list(map(int, input().split()))
    distance.append(row)

# Take starting city
start = int(input("Enter starting city (0 to N-1): "))


# Greedy Best First Search
def greedy_tsp(start=0):

    unvisited = set(range(N)) - {start}

    tour, current, total = [start], start, 0

    while unvisited:
        nxt = min(unvisited, key=lambda city: distance[current][city])

        total += distance[current][nxt]

        tour.append(nxt)

        unvisited.remove(nxt)

        current = nxt

    total += distance[current][start]

    tour.append(start)

    return tour, total


# A* Heuristic
def lower_bound(current, unvisited, start):

    if not unvisited:
        return distance[current][start]

    connection = min(distance[current][u] for u in unvisited)

    remaining = 0

    for u in unvisited:

        candidates = [distance[u][v] for v in unvisited if v != u]

        candidates.append(distance[u][start])

        remaining += min(candidates)

    return connection + remaining


# A* Search
def astar_tsp(start=0):

    initial_unvisited = frozenset(set(range(N)) - {start})

    pq = [(lower_bound(start, initial_unvisited, start),
           0, start, (start,), initial_unvisited)]

    best = {}

    while pq:

        f, cost, current, path, unvisited = heapq.heappop(pq)

        if not unvisited:
            return list(path) + [start], cost + distance[current][start]

        state = (current, unvisited)

        if best.get(state, float("inf")) <= cost:
            continue

        best[state] = cost

        for nxt in unvisited:

            new_unvisited = frozenset(unvisited - {nxt})

            new_cost = cost + distance[current][nxt]

            h = lower_bound(nxt, new_unvisited, start)

            heapq.heappush(
                pq,
                (new_cost + h, new_cost, nxt,
                 path + (nxt,), new_unvisited)
            )

    return None, float("inf")


# Display distance matrix
print("\nDistance Matrix:")

for row in distance:
    print(row)


# Execute algorithms
print("\nGreedy Best First Search:")
print("Tour and Distance:", greedy_tsp(start))

print("\nA* Search:")
print("Optimal Tour and Distance:", astar_tsp(start))
