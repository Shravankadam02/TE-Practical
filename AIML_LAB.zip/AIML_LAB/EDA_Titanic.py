# Assignment 10: EDA - Titanic dataset
import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

URL = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
df = pd.read_csv("Titanic.csv" if os.path.exists("Titanic.csv") else URL)
print(df.head())
print(df.info())
print("Missing values:\\n", df.isnull().sum())
df = df.drop_duplicates()
df = df.drop(columns=["PassengerId", "Name", "Ticket", "Cabin"], errors="ignore")
for col in ["Age", "Fare"]:
    df[col] = df[col].fillna(df[col].median())
if "Embarked" in df:
    df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])
df["Sex"] = df["Sex"].map({"male": 0, "female": 1})
df = pd.get_dummies(df, columns=["Embarked", "Pclass"], drop_first=True, dtype=int)
y = df.pop("Survived")
X = df
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
numeric = X_train.select_dtypes(include="number").columns
scaler = StandardScaler()
X_train[numeric] = scaler.fit_transform(X_train[numeric])
X_test[numeric] = scaler.transform(X_test[numeric])
print("Statistics:\\n", df.describe())
df.hist(figsize=(12, 9))
plt.tight_layout()
plt.show()
df.select_dtypes(include="number").plot(kind="box", subplots=True, layout=(3, 4), figsize=(14, 9), sharex=False)
plt.tight_layout()
plt.show()
print("Train:", X_train.shape, "Test:", X_test.shape)
