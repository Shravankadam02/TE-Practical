# Assignment 14: Linear Regression on Iris dataset
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

iris = load_iris(as_frame=True)
# Use sepal length, sepal width and petal width to predict petal length.
X = iris.data[["sepal width (cm)", "petal width (cm)", "sepal length (cm)"]]
y = iris.data["petal length (cm)"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LinearRegression()
model.fit(X_train, y_train)
pred = model.predict(X_test)
print("MSE:", mean_squared_error(y_test, pred))
print("MAE:", mean_absolute_error(y_test, pred))
print("R2 Score:", r2_score(y_test, pred))
plt.scatter(y_test, pred)
plt.xlabel("Actual Petal Length")
plt.ylabel("Predicted Petal Length")
plt.title("Iris Linear Regression: Actual vs Predicted")
plt.show()
