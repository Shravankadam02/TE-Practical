#Design and implement a simple intelligent agent for a smart home controller. Demonstrate the PEAS representation and agent behaviour.

print("-------Home Automation System-------\n")
motion = input("Motion detected? (Yes/No): ")
temperature = int(input("Enter the room temperature(C): "))
door = input("Door is Open (Yes/NO: )")
smoke = input("Smoke detected (Yes/No)")
print("\n")
if motion=="Yes":
  print("Action: Turn ON the security camera and lights")
else:
  print("Action: Turn OFF the security camera and lights")
if temperature > 30:
  print("Action: Turn ON AC")
elif temperature < 18:
  print("Action: Turn ON Heater")
else:
  print("Action: Temperature is Normal")
if door=="Yes":
  print("Action: Door is Open")
else:
  print("Action: Door is Secure")
if smoke=="Yes":
  print("Action: Activated Fire Alarm")
else:
  print("Action: No Smoke Detected")
