from collections import deque

# Maze representation
# 0 = Free cell
# 1 = Blocked cell

maze = [
    [0, 0, 0, 0],
    [1, 1, 0, 1],
    [0, 0, 0, 0],
    [0, 1, 1, 0]
]

# Breadth First Search Algorithm
def bfs(maze, start, goal):

    rows = len(maze)
    cols = len(maze[0])

    queue = deque([(start, [start])])
    visited = {start}

    # Possible movements: Up, Down, Left, Right
    directions = [
        (-1, 0),
        (1, 0),
        (0, -1),
        (0, 1)
    ]

    while queue:

        (x, y), path = queue.popleft()

        print("Visiting:", (x, y))

        # Check whether goal is reached
        if (x, y) == goal:
            return path

        # Explore neighbouring cells
        for dx, dy in directions:

            nx = x + dx
            ny = y + dy

            if (0 <= nx < rows and
                0 <= ny < cols and
                maze[nx][ny] == 0 and
                (nx, ny) not in visited):

                visited.add((nx, ny))

                queue.append(((nx, ny), path + [(nx, ny)]))

    return None


# Main program
print("------- BFS MAZE NAVIGATION -------")

print("\nMaze:")

for row in maze:
    print(row)

# Starting and goal positions
start = (0, 0)
goal = (3, 3)

print("\nStart Position:", start)
print("Goal Position:", goal)

# Check start and goal cells
if maze[start[0]][start[1]] == 1 or maze[goal[0]][goal[1]] == 1:

    print("\nStart or goal is blocked.")

else:

    path = bfs(maze, start, goal)

    if path:
        print("\nBFS Shortest Path:", path)
        print("Total Steps:", len(path) - 1)

    else:
        print("\nNo path found.")
