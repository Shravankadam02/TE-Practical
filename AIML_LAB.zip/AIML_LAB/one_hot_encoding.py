# Assignment 12: One-hot encoding of Titanic Sex, Embarked and Pclass
import os
import pandas as pd

URL = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
df = pd.read_csv("Titanic.csv" if os.path.exists("Titanic.csv") else URL)
df = df.drop(columns=["PassengerId", "Name", "Ticket", "Cabin"], errors="ignore")
df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])
df["Sex"] = df["Sex"].fillna(df["Sex"].mode()[0])
df["Pclass"] = df["Pclass"].fillna(df["Pclass"].mode()[0]).astype(str)
encoded = pd.get_dummies(df, columns=["Sex", "Embarked", "Pclass"], dtype=int)
print("Encoded dataset shape:", encoded.shape)
print(encoded.head())
