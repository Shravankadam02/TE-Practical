maze = [
    [0, 0, 0, 0],
    [1, 1, 0, 1],
    [0, 0, 0, 0],
    [0, 1, 1, 0]
]
def dfs(maze, start, goal):
    rows, cols = len(maze), len(maze[0])
    stack = [(start, [start])]
    visited = {start}
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    while stack:
        (x, y), path = stack.pop()
        print("Visiting:", (x, y))
        if (x, y) == goal:
            return path
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if (0 <= nx < rows and 0 <= ny < cols and
                    maze[nx][ny] == 0 and (nx, ny) not in visited):
                visited.add((nx, ny))
                stack.append(((nx, ny), path + [(nx, ny)]))
    return None

print("Maze:")
for row in maze:
    print(row)
print("DFS path:", dfs(maze, (0, 0), (3, 3)))
