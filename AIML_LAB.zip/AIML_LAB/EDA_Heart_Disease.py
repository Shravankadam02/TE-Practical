# Assignment 9: EDA - Heart Disease dataset
# Place processed.cleveland.data in this folder or use the UCI URL below.
import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/heart-disease/processed.cleveland.data"
COLUMNS = ["age","sex","cp","trestbps","chol","fbs","restecg","thalach","exang",
           "oldpeak","slope","ca","thal","target"]
path = "processed.cleveland.data"
df = pd.read_csv(path if os.path.exists(path) else URL, header=None, names=COLUMNS, na_values="?")
print(df.head())
print(df.info())
print("Missing values:\\n", df.isnull().sum())
df = df.drop_duplicates()
for col in df.columns:
    df[col] = pd.to_numeric(df[col], errors="coerce")
df = df.fillna(df.median(numeric_only=True))
df["target"] = (df["target"] > 0).astype(int)
X = df.drop(columns="target")
y = df["target"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
print("Statistics:\\n", df.describe())
df.hist(figsize=(12, 9))
plt.tight_layout()
plt.show()
df.plot(kind="box", subplots=True, layout=(4, 4), figsize=(14, 10), sharex=False)
plt.tight_layout()
plt.show()
print("Train:", X_train_scaled.shape, "Test:", X_test_scaled.shape)
